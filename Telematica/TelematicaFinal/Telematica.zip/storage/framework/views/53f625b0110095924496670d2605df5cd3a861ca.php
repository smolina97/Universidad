<?php $__env->startSection('content'); ?>
    <h3 class="text-center mb-3 pt-3">Editar el empleado <?php echo e($empleadoActualizar->id); ?></h3>

    <form action="<?php echo e(route('update' , $empleadoActualizar->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <input type="text" name="nombre" id="nombre" value="<?php echo e($empleadoActualizar->nombre); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="direccion" id="direccion" value="<?php echo e($empleadoActualizar->direccion); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="telefono" id="telefono" value="<?php echo e($empleadoActualizar->telefono); ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-warning btn-block">Editar empleado</button>
    </form>
    <?php if(session('update')): ?>
    
        <div class="alert alert-success mt-3">
            <?php echo e(session('update')); ?>

            echo '<meta http-equiv="Refresh" content="0;URL=../">';
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskCrud\resources\views/editar.blade.php ENDPATH**/ ?>